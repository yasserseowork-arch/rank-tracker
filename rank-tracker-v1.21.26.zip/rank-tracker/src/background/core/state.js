/**
 * state.js — طبقة التخزين والهجرة (Schema versioning)
 * chrome.storage.local  : الإعدادات + الكلمات + النتائج (دائمة)
 * chrome.storage.session: حالة التشغيل + السجلات (تُفقد عند إغلاق المتصفح عمداً)
 */
import { C } from './bridge.js';

export const SCHEMA_VERSION = 8;

export const K = {
  CONFIG: 'srt.config',
  KEYWORDS: 'srt.keywords',
  RESULTS: 'srt.results',
  RUN_STATS: 'srt.runStats',
  RUN: 'srt.run',
  LOGS: 'srt.logs',
  SCHEMA: 'srt.schemaVersion'
};

/** الإعدادات الافتراضية — المصدر الوحيد للحقيقة */
export const DEFAULT_CONFIG = {
  // الهوية المستهدفة
  storeDomain: '',
  storeName: '',
  storeNameEn: '',
  matchMode: 'both',            // domain | name | both
  // استهداف جغرافي ولغة SERP
  gl: '',   // المنطقة اختيارية تماماً — سيبتها فاضية = إعداد جوجل الافتراضي
  hl: '',   // اللغة اختيارية — سيبتها فاضية = لغة متصفحك
  num: 100,
  // الإيقاع البشري
  delayMs: 4000,                // مهلة إلزامية قبل كل كلمة (طلب المستخدم: 4 ثوانٍ)
  jitterMs: 1500,
  cooldownEvery: 8,             // كل N كلمات خذ استراحة طويلة
  cooldownMs: 30000,           // v1.20.5: 45←30 ثانية — الأمان لسه في الـcooldownEvery والـjitter العشوائي
  cooldownJitterMs: 20000,
  // الكابتشا
  captchaMaxAttempts: 2,
  captchaAttemptTimeoutMs: 35000,
  captchaGapMs: 2500,
  captchaRefreshRetries: 2,   // ريفرش صفحة الكابتشا ومحاولات جديدة عند الفشل
  pauseOnCaptchaFail: true,
  autoResumeOnManualSolve: true,
  // قراءة SERP
  settleMs: 1100,               // ⚡ 1.21.20 (طلب السرعة): الصفحة سيرفر-سايد من 1.21.4 — مفيش مبرر 1.8 ثانية
  scrollStepMs: 320,
  maxWaitResultsMs: 20000,      // قاعدة الـ20 ثانية: تُطبَّق بس لما العدّاد يوقف (مفيش نتائج جديدة)
  scanHardCapMs: 60000,         // السقف المطلق لمسح كلمة واحدة — لسه فيه تقدم؟ كمّل لحد هنا
  batchSettleMs: 2600,          // ⚡ 1.21.20: كانت 6500 من عصر ما قبل num=100 سيرفر-سايد — الدفعات الخلفية (selfFetchMore) ضهرة أمان، فالثبات اتقصّر
  rescanMs: 800,                // ⚡ 1.21.20:Ctrl+F دوري خفيف — نفس فولو-باك serp من 1.21.9
  selfFetchMore: true,          // الجلب الخلفي بقى افتراضي: مكمّل الدفعات لحد expectedNum لو السكرول وقف نص الطريق
  selfFetchMaxBatches: 9,       // أقصى دفعات خلفية (كل دفعة 10 نتائج) — تغطي 20→100
  maxChecksPerDay: 150,         // سقف يومي احتراماً لقواعد جوجل (0 = بدون سقف)
  errorReloadMax: 2,            // ريفرش تلقائي لصفحات الخطأ (عدد المرات)
  keywordRetries: 5,            // أي مشكلة؟ ريفرش + نفس الكلمة — عدد مرات إعادة المحاولة
  captchaClearRetries: 3,       // كابتشا؟ مسح بيانات المتصفح + تاب جديد — عدد المرات لكل كلمة
  // دورة العمل الكاملة (مثل السيناريو اليدوي)
  clearBeforeRun: true,         // مسح بيانات التصفح (كل الوقت) قبل بدء الجولة
  clearEveryN: 8,               // مسح دوري متزامن مع الاستراحة: كل 8 كلمات (0 = معطّل) — بصمة أقل وكابتشا أقل
  sheetUrl: '',                 // رابط شيت جوجل للمزامنة والكتابة
  sheetWriteBack: false,        // كتابة عمود الترتيب في الشيت عند انتهاء الجولة
  sheetStartCell: 'B1',         // خلية بداية لصق عمود الترتيب
  mapsCheck: true,              // فحص النتائج المحلية (خرائط) لكل كلمة — مثل السيناريو
  autoXlsx: true,               // تنزيل شيت Excel بالترتيب تلقائياً عند انتهاء الجولة
  // التبويبات
  foregroundTab: false,          // 🕊 v1.21.16 (طلب المستخدم): التبويبات بتفتح في الخلفية بهدوة — النافذة ماتبترفعش نفسها؛ التنشيط بيحصل لحظة ما عينه مطلوبة بس (شاشة التحدي)
  reuseTab: true,               // تبويب واحد دائم + تغيير الكلمة من صندوق البحث
  // متفرقات
  verbose: true,
  maxHistoryPerKeyword: 40
};

const local = {
  async get(key, fallback) {
    try {
      const obj = await chrome.storage.local.get(key);
      return obj && obj[key] !== undefined ? obj[key] : fallback;
    } catch (_) {
      return fallback;
    }
  },
  async set(key, value) {
    try { await chrome.storage.local.set({ [key]: value }); } catch (_) {}
  },
  async remove(key) {
    try { await chrome.storage.local.remove(key); } catch (_) {}
  }
};

const session = {
  async get(key, fallback) {
    try {
      if (!chrome.storage.session) { return fallback; }
      const obj = await chrome.storage.session.get(key);
      return obj && obj[key] !== undefined ? obj[key] : fallback;
    } catch (_) {
      return fallback;
    }
  },
  async set(key, value) {
    try { if (chrome.storage.session) { await chrome.storage.session.set({ [key]: value }); } } catch (_) {}
  }
};

/* ----------------------------- الإعدادات ----------------------------- */

export async function getConfig() {
  const stored = await local.get(K.CONFIG, {});
  return Object.assign({}, DEFAULT_CONFIG, stored || {});
}

/** 🔄 v1.21.9: رجوع لإعدادات المصنع — الكلمات والنتائج بره الحساب تمامًا */
export async function resetConfig() {
  await local.set(K.CONFIG, Object.assign({}, DEFAULT_CONFIG));
  return DEFAULT_CONFIG;
}

export async function setConfig(patch) {
  const current = await getConfig();
  const next = Object.assign({}, current, patch || {});
  // تطهير الأنواع
  const numeric = ['num', 'delayMs', 'jitterMs', 'cooldownEvery', 'cooldownMs', 'cooldownJitterMs',
    'captchaMaxAttempts', 'captchaAttemptTimeoutMs', 'captchaGapMs', 'captchaRefreshRetries', 'keywordRetries', 'captchaClearRetries', 'settleMs', 'scrollStepMs',
    'maxWaitResultsMs', 'maxHistoryPerKeyword', 'maxChecksPerDay', 'errorReloadMax',
    'batchSettleMs', 'rescanMs', 'selfFetchMaxBatches', 'scanHardCapMs', 'clearEveryN'];
  for (const key of numeric) {
    const n = parseInt(next[key], 10);
    if (!Number.isNaN(n)) { next[key] = n; }
  }
  const booleans = ['pauseOnCaptchaFail', 'autoResumeOnManualSolve', 'foregroundTab', 'reuseTab', 'verbose', 'selfFetchMore', 'clearBeforeRun', 'sheetWriteBack', 'mapsCheck', 'autoXlsx'];
  for (const key of booleans) { next[key] = !!next[key]; }
  if (!['domain', 'name', 'both'].includes(next.matchMode)) { next.matchMode = 'both'; }
  // تنظيف الدومين: المستخدم يكتبه بدون https وأحياناً بمسار أو www
  if (typeof next.storeDomain === 'string') {
    next.storeDomain = next.storeDomain.trim()
      .replace(/^[a-z][a-z0-9+.-]*:\/\//i, '')
      .replace(/[\/?#].*$/, '')
      .replace(/^www\./i, '')
      .toLowerCase();
  }
  // الاسمان (عربي/إنجليزي): trim وخفة، والسقف 80 حرف — من غير تغيير في المحتوى
  for (const nameKey of ['storeName', 'storeNameEn']) {
    if (typeof next[nameKey] === 'string') { next[nameKey] = next[nameKey].trim().slice(0, 80); }
  }
  next.delayMs = Math.max(1000, next.delayMs);
  next.num = Math.min(100, Math.max(10, next.num));
  await local.set(K.CONFIG, next);
  return next;
}

/* --------------------------- الكلمات المفتاحية --------------------------- */

export function makeKeywordId(keyword) {
  return 'kw_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
}

export async function getKeywords() {
  const list = await local.get(K.KEYWORDS, []);
  return Array.isArray(list) ? list : [];
}

export async function setKeywords(list) {
  await local.set(K.KEYWORDS, Array.isArray(list) ? list : []);
}

export async function updateKeyword(id, patch) {
  const list = await getKeywords();
  const idx = list.findIndex((k) => k.id === id);
  if (idx === -1) { return null; }
  list[idx] = Object.assign({}, list[idx], patch || {});
  await setKeywords(list);
  return list[idx];
}

export async function addKeywords(keywords, note) {
  const list = await getKeywords();
  const added = [];
  for (const raw of keywords || []) {
    const kw = String(raw || '').replace(/[\r\n\t]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 180);
    if (!kw) { continue; }
    // v1.21.1: المكررات مالهاش حذف ولا دمج — المستخدم بيشيل عمود الترتيب ويلصقه في
    // شيته سطر بسطر: أي سطر ناقص بيبلّط الشيت كله. نفس الكلمة مرتين = صفّين في مكانّين،
    // والفحص الذكي في queue بيخلي التاني مسخّرة من الأول من غير طلب تاني لجوجل
    const item = {
      id: makeKeywordId(kw),
      keyword: kw,
      note: note || '',
      status: C.STATUS.KW.PENDING,
      lastPosition: null,
      lastFound: null,
      lastCheckedAt: null,
      history: []
    };
    list.push(item);
    added.push(item);
  }
  await setKeywords(list);
  return { added: added, reset: 0 };
}

export async function removeKeyword(id) {
  const list = await getKeywords();
  await setKeywords(list.filter((k) => k.id !== id));
}

export async function clearKeywords() {
  await setKeywords([]);
}

/* -------------------------------- النتائج -------------------------------- */

export async function getResults() {
  const list = await local.get(K.RESULTS, []);
  return Array.isArray(list) ? list : [];
}

export async function addResult(row) {
  const list = await getResults();
  list.unshift(row);
  const cfg = await getConfig();
  const cap = Math.min(C.LIMITS.MAX_RESULTS_STORED, 2000);
  if (list.length > cap) { list.length = cap; }
  await local.set(K.RESULTS, list);
  void cfg;
  return row;
}

/* 📊 v1.21.7: إحصاءات الرنات — أساس تقدير الوقت وتقرير آخر رن (آخر 20) */
export async function getRunStats() {
  const list = await local.get(K.RUN_STATS, []);
  return Array.isArray(list) ? list : [];
}

export async function appendRunStat(entry) {
  const list = await getRunStats();
  list.push(entry);
  if (list.length > 20) { list.splice(0, list.length - 20); }
  await local.set(K.RUN_STATS, list);
  return entry;
}

export async function clearResults() {
  await local.set(K.RESULTS, []);
}

/* ------------------------------ حالة التشغيل ------------------------------ */

export const DEFAULT_RUN = {
  status: C.STATUS.RUN.IDLE,
  currentIndex: 0,
  startedAt: null,
  finishedAt: null,
  pauseReason: null,
  captcha: null,           // {tabId, attempts, lastError, since}
  checked: 0,
  found: 0,
  captchaSolves: 0,
  failures: 0
};

export async function getRun() {
  const run = await session.get(K.RUN, null);
  return Object.assign({}, DEFAULT_RUN, run || {});
}

export async function setRun(patch) {
  const run = await getRun();
  const next = Object.assign({}, run, patch || {});
  await session.set(K.RUN, next);
  return next;
}

/* --------------------------------- السجلات --------------------------------- */

export async function getLogs() {
  return session.get(K.LOGS, []);
}

export async function pushLog(entry) {
  const logs = await getLogs();
  logs.push(entry);
  if (logs.length > C.LIMITS.MAX_LOGS) { logs.splice(0, logs.length - C.LIMITS.MAX_LOGS); }
  await session.set(K.LOGS, logs);
  return entry;
}

export async function clearLogs() {
  await session.set(K.LOGS, []);
}

/* --------------------------------- الهجرة --------------------------------- */

/** عدّاد الفحوصات اليومي (سقف احتراماً لقواعد جوجل) */
export async function getDailyCount() {
  const today = new Date().toISOString().slice(0, 10);
  const stored = await local.get('srt.dailyCount', { date: today, count: 0 });
  if (stored.date !== today) { return { date: today, count: 0 }; }
  return stored;
}

export async function bumpDailyCount() {
  const current = await getDailyCount();
  const next = { date: current.date, count: current.count + 1 };
  await local.set('srt.dailyCount', next);
  return next;
}

export async function migrate() {
  const version = await local.get(K.SCHEMA, 0);
  if (version >= SCHEMA_VERSION) { return version; }
  if (version < 2) {
    // توحيد شكل الكلمات القديمة إن وجدت
    const list = await getKeywords();
    const fixed = list.map((k) => Object.assign({
      id: k.id || makeKeywordId(k.keyword || String(Math.random())),
      keyword: String(k.keyword || k.kw || ''),
      note: k.note || '',
      status: k.status || C.STATUS.KW.PENDING,
      lastPosition: k.lastPosition ?? null,
      lastFound: k.lastFound ?? null,
      lastCheckedAt: k.lastCheckedAt ?? null,
      history: Array.isArray(k.history) ? k.history : []
    }));
    await setKeywords(fixed);
  }
  if (version < 4) {
    // عادات جديدة: الكابتشا محاولتين بس، والمسح الدوري بقى متزامن مع الاستراحة (كل 8)
    const cfg = await getConfig();
    const patchCfg = {};
    const att = parseInt(cfg.captchaMaxAttempts, 10);
    if (!Number.isFinite(att) || att > 2) { patchCfg.captchaMaxAttempts = 2; }
    const cn = parseInt(cfg.clearEveryN, 10);
    if (!Number.isFinite(cn) || cn === 10) { patchCfg.clearEveryN = 8; }
    if (Object.keys(patchCfg).length) { await setConfig(patchCfg); }
  }
  if (version < 6) {
    // تسريع 1.20.5: الافتراضي القديم 45000 يتنقل لـ30000 — أي قيمة عدّلها المستخدم بيديها بتفضل
    const cfg = await getConfig();
    const patchCfg = {};
    if (parseInt(cfg.cooldownMs, 10) === 45000) { patchCfg.cooldownMs = 30000; }
    if (Object.keys(patchCfg).length) { await setConfig(patchCfg); }
  }
  if (version < 7) {
    // 🕊 v1.21.16: الوضع الهادي بقى هو_norm — الافتراضي القديم (true) المحفوظ بيتقلب
    // لـfalse. مفيش حاجة تانية في الإعدادات بتتحرك، والمسار الآلي للسكرول زي ما هو
    const cfg7 = await getConfig();
    if (cfg7.foregroundTab === true) { await setConfig({ foregroundTab: false }); }
  }
  if (version < 5) {
    // صبر المراكز الغويط: اللي راضي بقيم 1.19 الافتراضية ياخد القيم الجديدة؛
    // أي قيمة عدّلها المستخدم بنفسه بتفضل زي ما هي (ماعدا selfFetchMore — الأمان بقى افتراضي)
    const cfg = await getConfig();
    const patchCfg = {};
    if (parseInt(cfg.batchSettleMs, 10) === 5000) { patchCfg.batchSettleMs = 6500; }
    if (parseInt(cfg.selfFetchMaxBatches, 10) === 6) { patchCfg.selfFetchMaxBatches = 9; }
    if (cfg.selfFetchMore === false) { patchCfg.selfFetchMore = true; }
    if (Object.keys(patchCfg).length) { await setConfig(patchCfg); }
  }
  if (version < 8) {
    // ⚡ v1.21.20 (طلب المستخدم: «20 كلمة في نص ساعة بطيء»): الافتراضيات التقيلة القديمة
    // (settle 6.5ث / rescan 1.8ث / settle 1.8ث) بتتحدّث للقيم السريعة الجديدة — بس لو
    // المستخدم سابها زي الافتراضي؛ أي قيمة عدّلها بإيده بتفضل محمية
    const cfg8 = await getConfig();
    const patch8 = {};
    if (parseInt(cfg8.batchSettleMs, 10) === 6500) { patch8.batchSettleMs = 2600; }
    if (parseInt(cfg8.rescanMs, 10) === 1800) { patch8.rescanMs = 800; }
    if (parseInt(cfg8.settleMs, 10) === 1800) { patch8.settleMs = 1100; }
    if (Object.keys(patch8).length) { await setConfig(patch8); }
  }
  await local.set(K.SCHEMA, SCHEMA_VERSION);
  return SCHEMA_VERSION;
}

/* ------------------------------- نسخة شاملة ------------------------------- */

export async function snapshot() {
  const [config, keywords, results, run, logs] = await Promise.all([
    getConfig(), getKeywords(), getResults(), getRun(), getLogs()
  ]);
  return {
    version: C.VERSION,
    config,
    keywords,
    results: results.slice(0, 300),
    run,
    logs: logs.slice(-150),
    stats: computeStats(results, keywords)
  };
}

function computeStats(results, keywords) {
  const checked = results.length;
  const foundRows = results.filter((r) => r.found);
  const positions = foundRows.map((r) => r.position).filter((p) => typeof p === 'number');
  const avg = positions.length ? positions.reduce((a, b) => a + b, 0) / positions.length : null;
  return {
    checked,
    found: foundRows.length,
    notFound: checked - foundRows.length,
    avgPosition: avg === null ? null : Math.round(avg * 10) / 10,
    best: positions.length ? Math.min(...positions) : null,
    pending: keywords.filter((k) => k.status === C.STATUS.KW.PENDING).length,
    done: keywords.filter((k) => k.status === C.STATUS.KW.DONE).length,
    total: keywords.length
  };
}
